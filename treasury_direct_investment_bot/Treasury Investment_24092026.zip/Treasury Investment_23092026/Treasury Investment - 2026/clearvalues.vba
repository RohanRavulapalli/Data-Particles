Sub ClearRangeContents(sheetName As String, cellRange As String)
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Sheets(sheetName)
    ws.Range(cellRange).ClearContents
End Sub
